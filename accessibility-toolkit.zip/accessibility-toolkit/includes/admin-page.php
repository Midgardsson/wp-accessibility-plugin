<?php
/**
 * Admin Settings Page Template with Sidebar
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap atk-admin-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

    <?php settings_errors(); ?>

    <div class="atk-admin-layout">
        
        <!-- Main Settings Column -->
        <div class="atk-admin-main">
            <form method="post" action="options.php">
                <?php
                settings_fields('atk_settings_group');
                $settings = get_option('atk_settings', array());
                $defaults = array(
                    'widget_position' => 'floating',
                    'position_top' => '20px',
                    'position_bottom' => 'auto',
                    'position_left' => 'auto',
                    'position_right' => '20px',
                    'max_font_size' => 60,
                    'dark_bg_color' => '#121212',
                    'dark_text_color' => '#ffffff',
                    'dark_bg_opacity' => 0.95,
                    'high_contrast_bg' => '#000000',
                    'high_contrast_text' => '#ffff00'
                );
                $settings = wp_parse_args($settings, $defaults);
                ?>

                <table class="form-table">
                    <!-- Widget Position -->
                    <tr>
                        <th scope="row">
                            <label for="widget_position"><?php esc_html_e('Widget Position Mode', 'accessibility-toolkit'); ?></label>
                        </th>
                        <td>
                            <select name="atk_settings[widget_position]" id="widget_position" class="atk-position-select">
                                <option value="floating" <?php selected($settings['widget_position'], 'floating'); ?>>
                                    <?php esc_html_e('Floating (Circle)', 'accessibility-toolkit'); ?>
                                </option>
                                <option value="edge-left" <?php selected($settings['widget_position'], 'edge-left'); ?>>
                                    <?php esc_html_e('Edge Left (Rectangle)', 'accessibility-toolkit'); ?>
                                </option>
                                <option value="edge-right" <?php selected($settings['widget_position'], 'edge-right'); ?>>
                                    <?php esc_html_e('Edge Right (Rectangle)', 'accessibility-toolkit'); ?>
                                </option>
                                <option value="edge-bottom" <?php selected($settings['widget_position'], 'edge-bottom'); ?>>
                                    <?php esc_html_e('Edge Bottom (Rectangle)', 'accessibility-toolkit'); ?>
                                </option>
                            </select>
                            <p class="description">
                                <?php esc_html_e('Choose how the widget is positioned on the page.', 'accessibility-toolkit'); ?>
                            </p>
                        </td>
                    </tr>

                    <!-- Position Top -->
                    <tr class="atk-position-field" data-positions="floating,edge-left,edge-right">
                        <th scope="row">
                            <label for="position_top"><?php esc_html_e('Top Position', 'accessibility-toolkit'); ?></label>
                        </th>
                        <td>
                            <input type="text" name="atk_settings[position_top]" id="position_top"
                                   value="<?php echo esc_attr($settings['position_top']); ?>" class="regular-text">
                            <p class="description">
                                <?php esc_html_e('Distance from top (e.g., 20px, 10%, auto)', 'accessibility-toolkit'); ?>
                            </p>
                        </td>
                    </tr>

                    <!-- Position Bottom -->
                    <tr class="atk-position-field" data-positions="edge-bottom">
                        <th scope="row">
                            <label for="position_bottom"><?php esc_html_e('Bottom Position', 'accessibility-toolkit'); ?></label>
                        </th>
                        <td>
                            <input type="text" name="atk_settings[position_bottom]" id="position_bottom"
                                   value="<?php echo esc_attr($settings['position_bottom']); ?>" class="regular-text">
                            <p class="description">
                                <?php esc_html_e('Distance from bottom (e.g., 20px, 10%, auto)', 'accessibility-toolkit'); ?>
                            </p>
                        </td>
                    </tr>

                    <!-- Position Left -->
                    <tr class="atk-position-field" data-positions="floating,edge-left">
                        <th scope="row">
                            <label for="position_left"><?php esc_html_e('Left Position', 'accessibility-toolkit'); ?></label>
                        </th>
                        <td>
                            <input type="text" name="atk_settings[position_left]" id="position_left"
                                   value="<?php echo esc_attr($settings['position_left']); ?>" class="regular-text">
                            <p class="description">
                                <?php esc_html_e('Distance from left (e.g., 20px, 10%, auto)', 'accessibility-toolkit'); ?>
                            </p>
                        </td>
                    </tr>

                    <!-- Position Right -->
                    <tr class="atk-position-field" data-positions="floating,edge-right,edge-bottom">
                        <th scope="row">
                            <label for="position_right"><?php esc_html_e('Right Position', 'accessibility-toolkit'); ?></label>
                        </th>
                        <td>
                            <input type="text" name="atk_settings[position_right]" id="position_right"
                                   value="<?php echo esc_attr($settings['position_right']); ?>" class="regular-text">
                            <p class="description">
                                <?php esc_html_e('Distance from right (e.g., 20px, 10%, auto)', 'accessibility-toolkit'); ?>
                            </p>
                        </td>
                    </tr>

                    <!-- Max Font Size -->
                    <tr>
                        <th scope="row">
                            <label for="max_font_size"><?php esc_html_e('Maximum Font Size', 'accessibility-toolkit'); ?></label>
                        </th>
                        <td>
                            <input type="number" name="atk_settings[max_font_size]" id="max_font_size"
                                   value="<?php echo esc_attr($settings['max_font_size']); ?>" min="16" max="60" step="1">
                            <span>px</span>
                            <p class="description">
                                <?php esc_html_e('Maximum allowed font size (16-60px). Default: 60px', 'accessibility-toolkit'); ?>
                            </p>
                        </td>
                    </tr>

                    <!-- Dark Mode Section -->
                    <tr>
                        <th colspan="2">
                            <h2><?php esc_html_e('Dark Mode Settings', 'accessibility-toolkit'); ?></h2>
                        </th>
                    </tr>

                    <!-- Dark Mode Background Color -->
                    <tr>
                        <th scope="row">
                            <label for="dark_bg_color"><?php esc_html_e('Background Color', 'accessibility-toolkit'); ?></label>
                        </th>
                        <td>
                            <input type="text" name="atk_settings[dark_bg_color]" id="dark_bg_color"
                                   value="<?php echo esc_attr($settings['dark_bg_color']); ?>" class="atk-color-picker">
                            <p class="description">
                                <?php esc_html_e('Dark mode background color. Default: #121212 (Material Design standard)', 'accessibility-toolkit'); ?>
                            </p>
                        </td>
                    </tr>

                    <!-- Dark Mode Text Color -->
                    <tr>
                        <th scope="row">
                            <label for="dark_text_color"><?php esc_html_e('Text Color', 'accessibility-toolkit'); ?></label>
                        </th>
                        <td>
                            <input type="text" name="atk_settings[dark_text_color]" id="dark_text_color"
                                   value="<?php echo esc_attr($settings['dark_text_color']); ?>" class="atk-color-picker">
                            <p class="description">
                                <?php esc_html_e('Dark mode text color. Default: #ffffff', 'accessibility-toolkit'); ?>
                            </p>
                        </td>
                    </tr>

                    <!-- Dark Mode Background Opacity -->
                    <tr>
                        <th scope="row">
                            <label for="dark_bg_opacity"><?php esc_html_e('Background Opacity', 'accessibility-toolkit'); ?></label>
                        </th>
                        <td>
                            <input type="number" name="atk_settings[dark_bg_opacity]" id="dark_bg_opacity"
                                   value="<?php echo esc_attr($settings['dark_bg_opacity']); ?>" min="0" max="1" step="0.05">
                            <p class="description">
                                <?php esc_html_e('Background opacity (0.0 - 1.0). Default: 0.95', 'accessibility-toolkit'); ?>
                            </p>
                        </td>
                    </tr>

                    <!-- High Contrast Section -->
                    <tr>
                        <th colspan="2">
                            <h2><?php esc_html_e('High Contrast Settings', 'accessibility-toolkit'); ?></h2>
                        </th>
                    </tr>

                    <!-- High Contrast Background -->
                    <tr>
                        <th scope="row">
                            <label for="high_contrast_bg"><?php esc_html_e('Background Color', 'accessibility-toolkit'); ?></label>
                        </th>
                        <td>
                            <input type="text" name="atk_settings[high_contrast_bg]" id="high_contrast_bg"
                                   value="<?php echo esc_attr($settings['high_contrast_bg']); ?>" class="atk-color-picker">
                            <p class="description">
                                <?php esc_html_e('High contrast background color. Default: #000000', 'accessibility-toolkit'); ?>
                            </p>
                        </td>
                    </tr>

                    <!-- High Contrast Text -->
                    <tr>
                        <th scope="row">
                            <label for="high_contrast_text"><?php esc_html_e('Text Color', 'accessibility-toolkit'); ?></label>
                        </th>
                        <td>
                            <input type="text" name="atk_settings[high_contrast_text]" id="high_contrast_text"
                                   value="<?php echo esc_attr($settings['high_contrast_text']); ?>" class="atk-color-picker">
                            <p class="description">
                                <?php esc_html_e('High contrast text color. Default: #ffff00 (WCAG AAA standard)', 'accessibility-toolkit'); ?>
                            </p>
                        </td>
                    </tr>
                </table>

                <?php submit_button(__('Save Settings', 'accessibility-toolkit')); ?>
            </form>
        </div>

        <!-- Sidebar -->
        <div class="atk-admin-sidebar">
            
            <!-- About Plugin Box -->
            <div class="atk-sidebar-box">
                <h3>📖 <?php esc_html_e('About This Plugin', 'accessibility-toolkit'); ?></h3>
                <p><?php esc_html_e('This plugin provides comprehensive accessibility tools for your WordPress site, making it easier for all users to navigate and read your content.', 'accessibility-toolkit'); ?></p>
            </div>

            <!-- Features Box -->
            <div class="atk-sidebar-box">
                <h3>✨ <?php esc_html_e('Features', 'accessibility-toolkit'); ?></h3>
                <ul class="atk-feature-list">
                    <li>✅ <?php esc_html_e('Dynamic font size adjustment', 'accessibility-toolkit'); ?></li>
                    <li>✅ <?php esc_html_e('OpenDyslexic font support', 'accessibility-toolkit'); ?></li>
                    <li>✅ <?php esc_html_e('Dark mode', 'accessibility-toolkit'); ?></li>
                    <li>✅ <?php esc_html_e('High contrast mode', 'accessibility-toolkit'); ?></li>
                    <li>✅ <?php esc_html_e('Smart widget positioning', 'accessibility-toolkit'); ?></li>
                    <li>✅ <?php esc_html_e('User preferences saved', 'accessibility-toolkit'); ?></li>
                </ul>
            </div>

            <!-- How to Use Box -->
            <div class="atk-sidebar-box">
                <h3>🎯 <?php esc_html_e('How to Use', 'accessibility-toolkit'); ?></h3>
                <ol class="atk-usage-list">
                    <li><?php esc_html_e('Configure widget position and colors in the settings', 'accessibility-toolkit'); ?></li>
                    <li><?php esc_html_e('Visit your website to see the accessibility widget', 'accessibility-toolkit'); ?></li>
                    <li><?php esc_html_e('Users can adjust font sizes and enable accessibility features', 'accessibility-toolkit'); ?></li>
                    <li><?php esc_html_e('Settings are saved per-user in their browser', 'accessibility-toolkit'); ?></li>
                </ol>
            </div>

            <!-- Compliance Box -->
            <div class="atk-sidebar-box">
                <h3>✓ <?php esc_html_e('Compliance', 'accessibility-toolkit'); ?></h3>
                <p><?php esc_html_e('This plugin helps your site comply with:', 'accessibility-toolkit'); ?></p>
                <ul class="atk-compliance-list">
                    <li><strong>WCAG 2.1 AA</strong> - <?php esc_html_e('Web Content Accessibility Guidelines', 'accessibility-toolkit'); ?></li>
                    <li><strong>EU Directive</strong> - <?php esc_html_e('European Accessibility Act', 'accessibility-toolkit'); ?></li>
                    <li><strong>ADA</strong> - <?php esc_html_e('Americans with Disabilities Act', 'accessibility-toolkit'); ?></li>
                    <li><strong>Section 508</strong> - <?php esc_html_e('US Federal standard', 'accessibility-toolkit'); ?></li>
                </ul>
            </div>

           
            <div class="atk-sidebar-box atk-developer-boxx">
                <h3>🚀 <?php esc_html_e('Developer', 'accessibility-toolkit'); ?></h3>
                <div class="atk-developer-content">
                    <!-- ⚠️ PLACEHOLDER - Add your content here! -->
                    <p><strong>Midgardsson.no</strong></p>
                    <p><?php esc_html_e('Professional web solutions & accessibility consulting.', 'accessibility-toolkit'); ?></p>
                    <p>
                        <a href="https://midgardsson.no" target="_blank" class="button button-secondary">
                            <?php esc_html_e('Visit Website', 'accessibility-toolkit'); ?> →
                        </a>
                    </p>
                    <!-- Add your logo, links, etc here -->
                </div>
            </div>

            <!-- Support Box -->
            <div class="atk-sidebar-box">
                <h3>💬 <?php esc_html_e('Special Thanks To :  ', 'accessibility-toolkit'); ?></h3>
                <p><?php esc_html_e('Abbie from opendyslexic.org, who is the developer of OpenDyslexic font.   ', 'accessibility-toolkit'); ?></p>
                </ul>
            </div>

        </div>

    </div>
</div>